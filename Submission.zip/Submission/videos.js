var videos = [
    {
        "title": "Sample 1 Video",
        "artist-name": "Sample1",
        "url": "videos/sample1.mp4",
    },
    {
        "title": "Sample 2 Video",
        "artist-name": "Sample2",
        "url": "videos/sample2.mp4",
    },
    {
        "title": "Sample 3 Video",
        "artist-name": "Sample3",
        "url": "videos/sample3.mp4",
    },
    {
        "title": "Sample 4 Video",
        "artist-name": "Sample4",
        "url": "videos/sample4.mp4",
    }
]